let mapSort = require('./example.js');

result.mapSort = mapSort;