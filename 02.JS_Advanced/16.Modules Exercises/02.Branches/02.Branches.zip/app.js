let Branch = require('./branch')
let Employee = require('./employee');

result.Employee= Employee;
result.Branch = Branch;
