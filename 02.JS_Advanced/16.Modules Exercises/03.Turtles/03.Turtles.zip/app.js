let Turtle = require('./Turtle.js');
let WaterTurtle = require('./waterTurtle.js');
let GalapagosTurtle = require('./galapagosTurtle.js');
let EvkodianTurtle = require('./evkodianTurtle.js');
let NinjaTurtle = require('./ninjaTurtle.js');

result.Turtle = Turtle;
result.WaterTurtle = WaterTurtle;
result.GalapagosTurtle = GalapagosTurtle;
result.EvkodianTurtle = EvkodianTurtle;
result.NinjaTurtle = NinjaTurtle;
