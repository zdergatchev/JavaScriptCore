let Checkbox = require('./checkbox.js');
let Numberbox = require('./numberbox.js');

result.Checkbox = Checkbox;
result.Numberbox = Numberbox;