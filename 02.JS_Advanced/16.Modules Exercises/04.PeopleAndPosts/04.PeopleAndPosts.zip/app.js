let Person = require('./person.js');
let Post = require('./post.js');

result.Person = Person;
result.Post = Post;