let Employee = require('./employee.js');
let Junior = require('./junior.js');
let Senior = require('./senior.js');
let Manager = require('./manager.js');

result.Employee= Employee;
result.Junior = Junior;
result.Senior = Senior;
result.Manager = Manager;